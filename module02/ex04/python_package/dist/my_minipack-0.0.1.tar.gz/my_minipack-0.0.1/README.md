# MY VERY FISRT PYTHON PACKAGE

## You'll find two module inside:
* loading.py: a generatir function that decorate your loop with progression stats
* logger.py: a decorator function that add log meta data to the decorated functions